"use strict";
exports.__esModule = true;
//Declare Product
var prod = {
    productId: 1001,
    productName: "iPhone"
};
var productArray = [
    { productId: 1002, productName: "LG" },
    { productId: 1003, productName: "CoolPad" },
    { productId: 1004, productName: "Mi" },
];
console.log(prod.productId);
console.log(prod.productName);
for (var _i = 0, productArray_1 = productArray; _i < productArray_1.length; _i++) {
    var pro = productArray_1[_i];
    console.log(prod.productId);
    console.log(prod.productName);
}
