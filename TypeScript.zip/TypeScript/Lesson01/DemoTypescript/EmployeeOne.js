var EmployeeOne = (function () {
    function EmployeeOne(id, name) {
        this.empId = id;
        this.empName = name;
        EmployeeOne.numberOfEmployee++;
    }
    EmployeeOne.prototype.doGet = function () {
        document.write(this.empId + " " + this.empName);
    };
    EmployeeOne.getNumber = function () {
        return EmployeeOne.numberOfEmployee;
    };
    EmployeeOne.numberOfEmployee = 0;
    return EmployeeOne;
}());
var empOne = new EmployeeOne(1001, "Abcd");
empOne.doGet();
EmployeeOne.getNumber();
