var empName;
var empId;
