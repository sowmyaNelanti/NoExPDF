
export class IProduct {
    
    productId:number;
    productName:string;
}

export const company:string="capgemini";